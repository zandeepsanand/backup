export const environment = {
    production: true,
    apiUrl: "/api",
    originUrl: "https://newggera.herokuapp.com",
    wsUrl: "https://newggera.herokuapp.com",
    ggeraUrl: "https://api.ggera.com/static",
    ggeraToken:
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImVtYWlsIjoiYWRtaW5AZ2dlcmEuY29tIiwidXNlcm5hbWUiOiJBZG1pbiJ9LCJpYXQiOjE2Njc1MzQ5Mzh9.HQOPDeeGsY74hsZ-fHMmaOWr3oHCuHTaztqqYz0WnZw",
    ggeraPremade: "https://gaming.ggera.com/",
};
