export const environment = {
    production: true,
    apiUrl: "/api",
    originUrl: "https://newggera.herokuapp.com",
    wsUrl: "https://newggera.herokuapp.com",
    ggeraUrl: "https://api.ggera.com/static",
    ggeraToken:
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImVtYWlsIjoiZ2dlcmFfd2ViQGdnZXJhLmNvbSIsInVzZXJuYW1lIjoiR0dlcmEgV2ViIn0sImlhdCI6MTY3ODg5ODE2Nn0.UgUGsTciAYBuD9WCAReYAcSUKpWRvEMhCoYITDXvotE",
    ggeraPremade: "https://gaming.ggera.com/",
    
};
