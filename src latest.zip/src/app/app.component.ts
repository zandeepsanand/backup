import { Component } from '@angular/core';
declare let $: any;
declare var SDK: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angularboot5';
}
