import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { catchError, Observable, tap, throwError } from "rxjs";
import { environment } from "src/environments/environment";

interface TokenRefreshResponse {
  access_token: string;
  refresh_token: string;
}

@Injectable({
  providedIn: "root"
})
export class AuthService {
  private readonly refreshTokenUrl: string = `${environment.ggeraUrl}/token/refresh`;
  private readonly tokenKey: string = "token";
  server_address: string = environment.ggeraUrl;

  constructor( private httpClient: HttpClient) {
    const initialAccessToken = environment.ggeraToken;
    this.setAccessToken(initialAccessToken);
  }

  refreshToken(): Observable<any> {
    const refreshToken = this.getRefreshToken();
    console.log(refreshToken);
    
  
    if (!refreshToken) {
      return throwError("Refresh token not found");
    }
  
    const headers = new HttpHeaders().set("Authorization", refreshToken);
    const url = `${this.server_address}/token/refresh`;
  
    return this.httpClient.post<TokenRefreshResponse>(url, { headers }).pipe(
      tap((response: TokenRefreshResponse) => {
        const newAccessToken = response.access_token;
        const newRefreshToken = response.refresh_token;
        this.setAccessToken(newAccessToken);
        this.setRefreshToken(newRefreshToken);
        
        
      }),
      catchError((error) => {
        console.error("Error refreshing token:", error);
        return throwError(error);
      })
    );
  }

  public setAccessToken(token: string): void {
    localStorage.setItem(this.tokenKey, token);
  }

  public getAccessToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  public removeAccessToken(): void {
    localStorage.removeItem(this.tokenKey);
  }

  public setRefreshToken(refreshToken: string): void {
    localStorage.setItem("refreshToken", refreshToken);
  }

  public getRefreshToken(): string | null {
    return localStorage.getItem("refreshToken");
  }

  public removeRefreshToken(): void {
    localStorage.removeItem("refreshToken");
  }

}
